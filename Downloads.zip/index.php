<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>red voda </title>
    <link rel="stylesheet" href="styles4.css">
    <link rel="icon" href="08f7ff2ff1b807d2a8272c8a05b94a90.jpg" type="image/jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    
    </style>
</head>
<body>
    <div class="container">
        <form action="process_login.php" method="post">
            <h1>تسجيل دخول</h1>
            <div class="field">
                <input type="tel" name="phone" placeholder="Phone Number" id="phone" autocomplete="off">
            </div>
            <div class="field">
                <input type="password" name="password" placeholder="Password" id="password" autocomplete="new-password">
            </div>
            <button type="submit" class="login-button">سجل دخول</button>
            <p class="register-message">ليس لديك حساب ؟ <a href="register.php" class="register-link">سجل هنا</a></p>

        </form>
    </div>
    <footer>
        <p>
    <a target="_blank" href="https://github.com/KEPV18">kepv</a>
    تم إنشاؤها بـ <i class="fa fa-heart"></i> بواسطة
</p>


    </footer>
</body>
</html>
